<?php
/*
* All database connection variables
*/

define('DB_USER', "root"); // db user
define('DB_PASSWORD', ""); // db password (mention your db password here)
define('DB_DATABASE', "health_diet"); // database name
define('DB_SERVER', "localhost"); // db server

?>